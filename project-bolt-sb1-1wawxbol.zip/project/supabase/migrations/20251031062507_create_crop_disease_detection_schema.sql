/*
  # Crop Disease Detection System Schema

  ## Overview
  This migration creates the database schema for a crop disease detection application
  that uses machine learning to identify plant diseases from leaf images and continuously
  learns from user-submitted data.

  ## New Tables
  
  ### 1. `disease_categories`
  Stores information about different crop diseases
  - `id` (uuid, primary key) - Unique identifier for each disease
  - `name` (text) - Disease name
  - `description` (text) - Detailed description of the disease
  - `symptoms` (text) - Common symptoms to look for
  - `treatment` (text) - Recommended treatment methods
  - `created_at` (timestamptz) - Record creation timestamp
  
  ### 2. `disease_detections`
  Stores each disease detection submission from users
  - `id` (uuid, primary key) - Unique identifier for each detection
  - `image_url` (text) - URL to the uploaded leaf image
  - `detected_disease_id` (uuid, foreign key) - Reference to detected disease
  - `confidence_score` (decimal) - ML model confidence (0-1)
  - `user_feedback` (text) - Optional feedback from user about accuracy
  - `is_verified` (boolean) - Whether an expert has verified this detection
  - `created_at` (timestamptz) - Submission timestamp
  
  ### 3. `training_data`
  Stores images that will be used to improve the model
  - `id` (uuid, primary key) - Unique identifier
  - `detection_id` (uuid, foreign key) - Reference to original detection
  - `image_url` (text) - URL to the training image
  - `actual_disease_id` (uuid, foreign key) - Verified disease classification
  - `used_for_training` (boolean) - Whether this data has been used for retraining
  - `created_at` (timestamptz) - Record creation timestamp

  ## Security
  - Enable RLS on all tables
  - Allow public read access to disease categories
  - Allow public insert for disease detections and training data
  - Allow public read for their own submissions

  ## Indexes
  - Index on disease_detections.created_at for efficient querying
  - Index on training_data.used_for_training for model retraining queries
*/

-- Create disease_categories table
CREATE TABLE IF NOT EXISTS disease_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text DEFAULT '',
  symptoms text DEFAULT '',
  treatment text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

-- Create disease_detections table
CREATE TABLE IF NOT EXISTS disease_detections (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  image_url text NOT NULL,
  detected_disease_id uuid REFERENCES disease_categories(id),
  confidence_score decimal(5,4) DEFAULT 0.0,
  user_feedback text DEFAULT '',
  is_verified boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Create training_data table
CREATE TABLE IF NOT EXISTS training_data (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  detection_id uuid REFERENCES disease_detections(id),
  image_url text NOT NULL,
  actual_disease_id uuid REFERENCES disease_categories(id),
  used_for_training boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_disease_detections_created_at ON disease_detections(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_training_data_unused ON training_data(used_for_training) WHERE used_for_training = false;

-- Enable Row Level Security
ALTER TABLE disease_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE disease_detections ENABLE ROW LEVEL SECURITY;
ALTER TABLE training_data ENABLE ROW LEVEL SECURITY;

-- RLS Policies for disease_categories (public read)
CREATE POLICY "Anyone can view disease categories"
  ON disease_categories FOR SELECT
  USING (true);

-- RLS Policies for disease_detections (public insert and read)
CREATE POLICY "Anyone can insert disease detections"
  ON disease_detections FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Anyone can view disease detections"
  ON disease_detections FOR SELECT
  USING (true);

-- RLS Policies for training_data (public insert and read)
CREATE POLICY "Anyone can insert training data"
  ON training_data FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Anyone can view training data"
  ON training_data FOR SELECT
  USING (true);

-- Insert sample disease categories
INSERT INTO disease_categories (name, description, symptoms, treatment) VALUES
  ('Healthy', 'No disease detected - plant is healthy', 'Green leaves, no spots or discoloration', 'Continue regular care and monitoring'),
  ('Early Blight', 'Fungal disease causing dark spots on leaves', 'Dark brown spots with concentric rings, yellowing leaves', 'Remove affected leaves, apply fungicide, improve air circulation'),
  ('Late Blight', 'Destructive fungal disease affecting leaves and fruit', 'Water-soaked spots, white fungal growth, rapid leaf death', 'Apply copper-based fungicide, remove infected plants immediately'),
  ('Leaf Mold', 'Fungal infection thriving in humid conditions', 'Yellow spots on upper leaf surface, olive-green mold underneath', 'Reduce humidity, improve ventilation, apply fungicide'),
  ('Septoria Leaf Spot', 'Fungal disease with characteristic circular spots', 'Small circular spots with dark borders and gray centers', 'Remove infected leaves, avoid overhead watering, use fungicide'),
  ('Bacterial Spot', 'Bacterial infection causing dark lesions', 'Small dark spots with yellow halos, leaf drop', 'Use copper sprays, plant resistant varieties, remove infected plants'),
  ('Mosaic Virus', 'Viral disease causing mottled patterns', 'Yellow and green mottled patterns, stunted growth', 'Remove infected plants, control aphids, use resistant varieties'),
  ('Powdery Mildew', 'Fungal disease with white powdery coating', 'White powdery substance on leaves, curled leaves', 'Apply sulfur or neem oil, improve air flow, water at base of plant')
ON CONFLICT DO NOTHING;
