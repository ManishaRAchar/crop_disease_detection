/*
  # Add User History and Detection Records

  ## Overview
  This migration adds user history tracking to the crop disease detection system.
  Authenticated users can now view their detection history and track their submissions over time.

  ## New Tables
  
  ### 1. `user_detection_history`
  Tracks all disease detections made by authenticated users
  - `id` (uuid, primary key) - Unique identifier
  - `user_id` (uuid, foreign key) - Reference to auth.users
  - `detection_id` (uuid, foreign key) - Reference to disease_detections
  - `disease_name` (text) - Cached disease name for quick access
  - `confidence_score` (decimal) - Cached confidence for quick access
  - `image_url` (text) - Image URL for history display
  - `created_at` (timestamptz) - When the detection was made

  ## Modified Tables
  
  ### `disease_detections`
  - Added `user_id` (uuid, nullable) - Link to authenticated user
  - Added `is_public` (boolean) - Whether this submission is public for community learning

  ## Security
  - Enable RLS on user_detection_history
  - Users can only view their own detection history
  - Public detections can be viewed by others for community learning
  - All user data is private by default
*/

-- Alter disease_detections to add user tracking
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'disease_detections' AND column_name = 'user_id'
  ) THEN
    ALTER TABLE disease_detections ADD COLUMN user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'disease_detections' AND column_name = 'is_public'
  ) THEN
    ALTER TABLE disease_detections ADD COLUMN is_public boolean DEFAULT false;
  END IF;
END $$;

-- Create user_detection_history table
CREATE TABLE IF NOT EXISTS user_detection_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  detection_id uuid NOT NULL REFERENCES disease_detections(id) ON DELETE CASCADE,
  disease_name text NOT NULL,
  confidence_score decimal(5,4) NOT NULL,
  image_url text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_user_detection_history_user_id ON user_detection_history(user_id);
CREATE INDEX IF NOT EXISTS idx_user_detection_history_created_at ON user_detection_history(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_disease_detections_user_id ON disease_detections(user_id);

-- Enable Row Level Security
ALTER TABLE user_detection_history ENABLE ROW LEVEL SECURITY;

-- RLS Policies for user_detection_history
CREATE POLICY "Users can view their own detection history"
  ON user_detection_history FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own detection history"
  ON user_detection_history FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own detection history"
  ON user_detection_history FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Drop old policy if exists
DROP POLICY IF EXISTS "Anyone can view disease detections" ON disease_detections;

-- Create new RLS policies for disease_detections
CREATE POLICY "Anyone can view public detections or anonymous"
  ON disease_detections FOR SELECT
  USING (is_public = true OR user_id IS NULL);

CREATE POLICY "Users can view their own detections"
  ON disease_detections FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Anyone can insert anonymous detections"
  ON disease_detections FOR INSERT
  WITH CHECK (user_id IS NULL);

CREATE POLICY "Authenticated users can insert their detections"
  ON disease_detections FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id OR user_id IS NULL);
