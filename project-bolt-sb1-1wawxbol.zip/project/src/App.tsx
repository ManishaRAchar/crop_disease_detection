import { useState, useEffect } from 'react';
import { Loader } from 'lucide-react';
import { useAuth } from './context/AuthContext';
import HomeScreen from './components/HomeScreen';
import LoginScreen from './components/LoginScreen';
import RegisterScreen from './components/RegisterScreen';
import DetectionScreen from './components/DetectionScreen';
import ResultsScreen from './components/ResultsScreen';
import ThankYouScreen from './components/ThankYouScreen';
import HistoryScreen from './components/HistoryScreen';
import { DetectionResult } from './components/DetectionScreen';

type Screen = 'home' | 'login' | 'register' | 'detection' | 'results' | 'thankyou' | 'history';

function App() {
  const { user, loading: authLoading, isAuthenticated } = useAuth();
  const [currentScreen, setCurrentScreen] = useState<Screen>('home');
  const [detectionResult, setDetectionResult] = useState<DetectionResult | null>(null);
  const [authScreen, setAuthScreen] = useState<'login' | 'register'>('login');

  useEffect(() => {
    if (!authLoading && isAuthenticated && currentScreen === 'home') {
      setCurrentScreen('home');
    }
  }, [authLoading, isAuthenticated, currentScreen]);

  if (authLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 flex items-center justify-center">
        <Loader className="w-12 h-12 text-green-600 animate-spin" />
      </div>
    );
  }

  const handleStart = () => {
    if (isAuthenticated) {
      setCurrentScreen('detection');
    } else {
      setAuthScreen('login');
      setCurrentScreen('login');
    }
  };

  const handleDetectionComplete = (result: DetectionResult) => {
    setDetectionResult(result);
    setCurrentScreen('results');
  };

  const handleContinue = () => {
    setCurrentScreen('thankyou');
  };

  const handleRestart = () => {
    setDetectionResult(null);
    if (isAuthenticated) {
      setCurrentScreen('history');
    } else {
      setCurrentScreen('home');
    }
  };

  const handleLogout = () => {
    setCurrentScreen('home');
  };

  const handleLoginSuccess = () => {
    setCurrentScreen('detection');
  };

  const handleRegisterSuccess = () => {
    setCurrentScreen('detection');
  };

  return (
    <>
      {currentScreen === 'home' && (
        <HomeScreen onStart={handleStart} />
      )}
      {currentScreen === 'login' && (
        <LoginScreen
          onSuccess={handleLoginSuccess}
          onSwitchToRegister={() => {
            setAuthScreen('register');
            setCurrentScreen('register');
          }}
        />
      )}
      {currentScreen === 'register' && (
        <RegisterScreen
          onSuccess={handleRegisterSuccess}
          onSwitchToLogin={() => {
            setAuthScreen('login');
            setCurrentScreen('login');
          }}
        />
      )}
      {currentScreen === 'detection' && (
        <DetectionScreen onComplete={handleDetectionComplete} />
      )}
      {currentScreen === 'results' && detectionResult && (
        <ResultsScreen result={detectionResult} onContinue={handleContinue} />
      )}
      {currentScreen === 'thankyou' && (
        <ThankYouScreen onRestart={handleRestart} />
      )}
      {currentScreen === 'history' && (
        <HistoryScreen onLogout={handleLogout} />
      )}
    </>
  );
}

export default App;
