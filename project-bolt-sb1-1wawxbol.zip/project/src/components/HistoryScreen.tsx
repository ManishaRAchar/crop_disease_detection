import { useState, useEffect } from 'react';
import { History, LogOut, Loader, AlertCircle, Trash2, Eye } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../lib/supabase';
import { signOut } from '../lib/auth';

interface HistoryItem {
  id: string;
  disease_name: string;
  confidence_score: number;
  image_url: string;
  created_at: string;
}

interface HistoryScreenProps {
  onLogout: () => void;
  onViewDetection?: (detection: HistoryItem) => void;
}

export default function HistoryScreen({ onLogout, onViewDetection }: HistoryScreenProps) {
  const { user } = useAuth();
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');
  const [selectedDetection, setSelectedDetection] = useState<HistoryItem | null>(null);

  useEffect(() => {
    fetchHistory();
  }, [user?.id]);

  const fetchHistory = async () => {
    if (!user?.id) return;

    setIsLoading(true);
    try {
      const { data, error: fetchError } = await supabase
        .from('user_detection_history')
        .select('id, disease_name, confidence_score, image_url, created_at')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (fetchError) throw fetchError;
      setHistory(data || []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch history');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteItem = async (id: string) => {
    if (!confirm('Are you sure you want to delete this detection record?')) return;

    try {
      const { error: deleteError } = await supabase
        .from('user_detection_history')
        .delete()
        .eq('id', id);

      if (deleteError) throw deleteError;
      setHistory(history.filter(item => item.id !== id));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete record');
    }
  };

  const handleLogout = async () => {
    await signOut();
    onLogout();
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const getConfidenceColor = (score: number) => {
    if (score >= 0.8) return 'text-green-600';
    if (score >= 0.6) return 'text-yellow-600';
    return 'text-orange-600';
  };

  const getConfidenceBg = (score: number) => {
    if (score >= 0.8) return 'bg-green-50';
    if (score >= 0.6) return 'bg-yellow-50';
    return 'bg-orange-50';
  };

  if (selectedDetection) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 py-12 px-4">
        <div className="max-w-4xl mx-auto">
          <button
            onClick={() => setSelectedDetection(null)}
            className="mb-6 px-6 py-2 bg-gray-200 hover:bg-gray-300 text-gray-800 font-medium rounded-lg transition"
          >
            Back to History
          </button>

          <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
            <div className="bg-gradient-to-r from-green-600 to-emerald-600 p-6">
              <h2 className="text-2xl font-bold text-white">
                {selectedDetection.disease_name}
              </h2>
              <p className="text-green-50 mt-1">
                {formatDate(selectedDetection.created_at)}
              </p>
            </div>

            <div className="p-8">
              <img
                src={selectedDetection.image_url}
                alt="Detected leaf"
                className="w-full h-64 object-cover rounded-xl border-2 border-gray-200 mb-6"
              />

              <div className="flex items-center gap-4 mb-6">
                <div className="flex-1">
                  <p className="text-sm text-gray-600 mb-1">Confidence Score</p>
                  <div className="w-full bg-gray-200 rounded-full h-4 overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all ${
                        selectedDetection.confidence_score >= 0.8
                          ? 'bg-green-600'
                          : selectedDetection.confidence_score >= 0.6
                          ? 'bg-yellow-500'
                          : 'bg-orange-500'
                      }`}
                      style={{ width: `${selectedDetection.confidence_score * 100}%` }}
                    />
                  </div>
                </div>
                <span className={`text-lg font-bold ${getConfidenceColor(selectedDetection.confidence_score)}`}>
                  {Math.round(selectedDetection.confidence_score * 100)}%
                </span>
              </div>

              <div className="p-6 bg-blue-50 border border-blue-200 rounded-xl">
                <h3 className="font-semibold text-gray-900 mb-2">About This Detection</h3>
                <p className="text-gray-700">
                  This leaf was detected as having {selectedDetection.disease_name.toLowerCase()}
                  with a confidence score of {Math.round(selectedDetection.confidence_score * 100)}%.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 py-12 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-4xl font-bold text-gray-900 flex items-center gap-3">
              <History className="w-10 h-10 text-green-600" />
              Detection History
            </h1>
            <p className="text-gray-600 mt-2">
              {user?.email}
            </p>
          </div>

          <button
            onClick={handleLogout}
            className="px-6 py-3 bg-red-600 hover:bg-red-700 text-white font-semibold rounded-lg shadow-lg transition flex items-center gap-2"
          >
            <LogOut className="w-5 h-5" />
            Logout
          </button>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <Loader className="w-8 h-8 text-green-600 animate-spin" />
          </div>
        ) : error ? (
          <div className="p-6 bg-red-50 border border-red-200 rounded-xl flex items-start gap-4">
            <AlertCircle className="w-6 h-6 text-red-600 flex-shrink-0 mt-1" />
            <div>
              <h3 className="font-semibold text-red-900 mb-1">Error Loading History</h3>
              <p className="text-red-800">{error}</p>
            </div>
          </div>
        ) : history.length === 0 ? (
          <div className="bg-white rounded-2xl shadow-lg p-16 text-center">
            <History className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-gray-900 mb-2">No Detections Yet</h2>
            <p className="text-gray-600">
              Start analyzing leaf images to build your detection history
            </p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {history.map((item) => (
              <div
                key={item.id}
                className={`${getConfidenceBg(item.confidence_score)} rounded-xl shadow-lg overflow-hidden border border-gray-200 transform transition hover:scale-105`}
              >
                <div className="relative h-40 overflow-hidden">
                  <img
                    src={item.image_url}
                    alt={item.disease_name}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                  <div className="absolute bottom-3 left-3 right-3">
                    <p className="text-white font-bold text-lg">{item.disease_name}</p>
                  </div>
                </div>

                <div className="p-4">
                  <div className="flex items-center justify-between mb-3">
                    <span className={`font-bold text-sm ${getConfidenceColor(item.confidence_score)}`}>
                      {Math.round(item.confidence_score * 100)}% Confidence
                    </span>
                  </div>

                  <p className="text-xs text-gray-600 mb-4">
                    {formatDate(item.created_at)}
                  </p>

                  <div className="flex gap-2">
                    <button
                      onClick={() => setSelectedDetection(item)}
                      className="flex-1 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition flex items-center justify-center gap-1 text-sm"
                    >
                      <Eye className="w-4 h-4" />
                      View
                    </button>
                    <button
                      onClick={() => handleDeleteItem(item.id)}
                      className="px-3 py-2 bg-red-100 hover:bg-red-200 text-red-700 font-medium rounded-lg transition"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
