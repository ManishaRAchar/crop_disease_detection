import { useState, useRef } from 'react';
import { Upload, Loader, AlertCircle, Camera } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { supabase, DiseaseCategory } from '../lib/supabase';

interface DetectionScreenProps {
  onComplete: (result: DetectionResult) => void;
}

export interface DetectionResult {
  disease: DiseaseCategory;
  confidence: number;
  imageUrl: string;
  detectionId: string;
}

export default function DetectionScreen({ onComplete }: DetectionScreenProps) {
  const { user } = useAuth();
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string>('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [error, setError] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        setError('Please select a valid image file');
        return;
      }
      setSelectedFile(file);
      setPreviewUrl(URL.createObjectURL(file));
      setError('');
    }
  };

  const simulateDetection = async (): Promise<DiseaseCategory> => {
    const { data: diseases } = await supabase
      .from('disease_categories')
      .select('*');

    if (!diseases || diseases.length === 0) {
      throw new Error('No disease categories found');
    }

    const randomDisease = diseases[Math.floor(Math.random() * diseases.length)];
    return randomDisease;
  };

  const handleAnalyze = async () => {
    if (!selectedFile) {
      setError('Please select an image first');
      return;
    }

    setIsAnalyzing(true);
    setError('');

    try {
      const fileExt = selectedFile.name.split('.').pop();
      const fileName = `${Math.random().toString(36).substring(2)}_${Date.now()}.${fileExt}`;
      const filePath = `leaf-images/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('crop-images')
        .upload(filePath, selectedFile);

      let imageUrl = previewUrl;
      if (!uploadError) {
        const { data: urlData } = supabase.storage
          .from('crop-images')
          .getPublicUrl(filePath);
        imageUrl = urlData.publicUrl;
      }

      await new Promise(resolve => setTimeout(resolve, 2000));

      const detectedDisease = await simulateDetection();
      const confidenceScore = 0.75 + Math.random() * 0.24;

      const { data: detection, error: insertError } = await supabase
        .from('disease_detections')
        .insert({
          image_url: imageUrl,
          detected_disease_id: detectedDisease.id,
          confidence_score: confidenceScore,
          user_id: user?.id || null,
          is_public: false,
        })
        .select()
        .single();

      if (insertError) throw insertError;

      await supabase.from('training_data').insert({
        detection_id: detection.id,
        image_url: imageUrl,
        actual_disease_id: detectedDisease.id,
        used_for_training: false,
      });

      if (user?.id) {
        await supabase.from('user_detection_history').insert({
          user_id: user.id,
          detection_id: detection.id,
          disease_name: detectedDisease.name,
          confidence_score: confidenceScore,
          image_url: imageUrl,
        });
      }

      onComplete({
        disease: detectedDisease,
        confidence: confidenceScore,
        imageUrl: imageUrl,
        detectionId: detection.id,
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Analysis failed');
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-3">
            Upload Leaf Image
          </h1>
          <p className="text-lg text-gray-600">
            Take or upload a clear photo of the affected leaf for analysis
          </p>
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-8">
          <div className="mb-8">
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleFileSelect}
              className="hidden"
            />

            {!previewUrl ? (
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-3 border-dashed border-gray-300 rounded-xl p-12 text-center cursor-pointer hover:border-green-500 hover:bg-green-50 transition"
              >
                <Camera className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <p className="text-lg font-medium text-gray-700 mb-2">
                  Click to upload image
                </p>
                <p className="text-sm text-gray-500">
                  PNG, JPG, or JPEG up to 10MB
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="relative rounded-xl overflow-hidden border-2 border-gray-200">
                  <img
                    src={previewUrl}
                    alt="Preview"
                    className="w-full h-auto max-h-96 object-contain bg-gray-50"
                  />
                </div>
                <button
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isAnalyzing}
                  className="w-full py-3 border-2 border-gray-300 rounded-xl text-gray-700 font-medium hover:bg-gray-50 transition disabled:opacity-50"
                >
                  Choose Different Image
                </button>
              </div>
            )}
          </div>

          {error && (
            <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
              <p className="text-red-800 text-sm">{error}</p>
            </div>
          )}

          <button
            onClick={handleAnalyze}
            disabled={!selectedFile || isAnalyzing}
            className="w-full py-4 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-xl shadow-lg disabled:opacity-50 disabled:cursor-not-allowed transition flex items-center justify-center gap-3"
          >
            {isAnalyzing ? (
              <>
                <Loader className="w-5 h-5 animate-spin" />
                Analyzing Image...
              </>
            ) : (
              <>
                <Upload className="w-5 h-5" />
                Analyze Disease
              </>
            )}
          </button>

          <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <p className="text-sm text-blue-800">
              <strong>Tip:</strong> For best results, ensure the leaf is well-lit,
              in focus, and takes up most of the frame. Avoid shadows and blurry images.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
