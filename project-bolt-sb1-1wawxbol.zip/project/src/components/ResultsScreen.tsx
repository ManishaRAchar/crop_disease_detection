import { useState } from 'react';
import { CheckCircle, AlertTriangle, Info, ThumbsUp, ThumbsDown, Send } from 'lucide-react';
import { DetectionResult } from './DetectionScreen';
import { supabase } from '../lib/supabase';

interface ResultsScreenProps {
  result: DetectionResult;
  onContinue: () => void;
}

export default function ResultsScreen({ result, onContinue }: ResultsScreenProps) {
  const [feedback, setFeedback] = useState('');
  const [feedbackSubmitted, setFeedbackSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const isHealthy = result.disease.name.toLowerCase() === 'healthy';
  const confidencePercentage = Math.round(result.confidence * 100);

  const handleSubmitFeedback = async () => {
    if (!feedback.trim()) return;

    setIsSubmitting(true);
    try {
      await supabase
        .from('disease_detections')
        .update({ user_feedback: feedback })
        .eq('id', result.detectionId);

      setFeedbackSubmitted(true);
    } catch (err) {
      console.error('Failed to submit feedback:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
          <div className={`p-6 ${isHealthy ? 'bg-green-50' : 'bg-orange-50'}`}>
            <div className="flex items-center gap-4">
              {isHealthy ? (
                <CheckCircle className="w-12 h-12 text-green-600" />
              ) : (
                <AlertTriangle className="w-12 h-12 text-orange-600" />
              )}
              <div>
                <h2 className="text-3xl font-bold text-gray-900">
                  {result.disease.name}
                </h2>
                <p className="text-lg text-gray-600 mt-1">
                  Confidence: {confidencePercentage}%
                </p>
              </div>
            </div>
          </div>

          <div className="p-8">
            <div className="mb-8">
              <img
                src={result.imageUrl}
                alt="Analyzed leaf"
                className="w-full h-64 object-cover rounded-xl border-2 border-gray-200"
              />
            </div>

            <div className="mb-4 flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
              <div className="flex-shrink-0 w-full bg-gray-200 rounded-full h-3 overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all ${
                    confidencePercentage >= 80
                      ? 'bg-green-600'
                      : confidencePercentage >= 60
                      ? 'bg-yellow-500'
                      : 'bg-orange-500'
                  }`}
                  style={{ width: `${confidencePercentage}%` }}
                />
              </div>
            </div>

            <div className="space-y-6 mb-8">
              <div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2 flex items-center gap-2">
                  <Info className="w-5 h-5 text-blue-600" />
                  Description
                </h3>
                <p className="text-gray-700 leading-relaxed">
                  {result.disease.description}
                </p>
              </div>

              {!isHealthy && (
                <>
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">
                      Common Symptoms
                    </h3>
                    <p className="text-gray-700 leading-relaxed">
                      {result.disease.symptoms}
                    </p>
                  </div>

                  <div className="bg-green-50 border-l-4 border-green-600 p-5 rounded-r-lg">
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">
                      Recommended Treatment
                    </h3>
                    <p className="text-gray-700 leading-relaxed">
                      {result.disease.treatment}
                    </p>
                  </div>
                </>
              )}
            </div>

            <div className="border-t border-gray-200 pt-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">
                Help Improve Our Model
              </h3>
              <p className="text-gray-600 text-sm mb-4">
                Was this detection accurate? Your feedback helps train the AI to provide
                better results for everyone.
              </p>

              {!feedbackSubmitted ? (
                <div className="space-y-3">
                  <div className="flex gap-3">
                    <button
                      onClick={() => setFeedback('Accurate detection')}
                      className="flex-1 py-3 px-4 border-2 border-green-600 text-green-700 rounded-lg hover:bg-green-50 transition flex items-center justify-center gap-2 font-medium"
                    >
                      <ThumbsUp className="w-5 h-5" />
                      Accurate
                    </button>
                    <button
                      onClick={() => setFeedback('Inaccurate detection')}
                      className="flex-1 py-3 px-4 border-2 border-red-600 text-red-700 rounded-lg hover:bg-red-50 transition flex items-center justify-center gap-2 font-medium"
                    >
                      <ThumbsDown className="w-5 h-5" />
                      Not Accurate
                    </button>
                  </div>

                  <textarea
                    value={feedback}
                    onChange={(e) => setFeedback(e.target.value)}
                    placeholder="Additional comments (optional)..."
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent resize-none"
                    rows={3}
                  />

                  <button
                    onClick={handleSubmitFeedback}
                    disabled={!feedback.trim() || isSubmitting}
                    className="w-full py-3 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-lg disabled:opacity-50 disabled:cursor-not-allowed transition flex items-center justify-center gap-2"
                  >
                    <Send className="w-5 h-5" />
                    {isSubmitting ? 'Submitting...' : 'Submit Feedback'}
                  </button>
                </div>
              ) : (
                <div className="p-4 bg-green-50 border border-green-200 rounded-lg flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  <p className="text-green-800 font-medium">
                    Thank you for your feedback! It helps improve our model.
                  </p>
                </div>
              )}
            </div>

            <button
              onClick={onContinue}
              className="w-full mt-6 py-4 bg-gray-900 hover:bg-gray-800 text-white font-semibold rounded-xl shadow-lg transition"
            >
              Continue
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
