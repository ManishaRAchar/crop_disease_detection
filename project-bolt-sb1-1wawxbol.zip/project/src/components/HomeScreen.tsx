import { Leaf, Brain, Database, CheckCircle, History, LogIn } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface HomeScreenProps {
  onStart: () => void;
}

export default function HomeScreen({ onStart }: HomeScreenProps) {
  const { isAuthenticated } = useAuth();
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50">
      <div className="max-w-6xl mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-green-600 rounded-full mb-6">
            <Leaf className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-5xl font-bold text-gray-900 mb-4">
            Crop Disease Detection
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            AI-powered plant disease identification to help farmers protect their crops
            and improve yields through early detection and intervention
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-12">
          <div className="bg-white rounded-xl shadow-lg p-8 transform transition hover:scale-105">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
              <Brain className="w-6 h-6 text-blue-600" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-3">
              Smart Detection
            </h3>
            <p className="text-gray-600 leading-relaxed">
              Advanced CNN-based deep learning model that analyzes leaf images
              to identify diseases with high accuracy and confidence scores
            </p>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-8 transform transition hover:scale-105">
            <div className="w-12 h-12 bg-emerald-100 rounded-lg flex items-center justify-center mb-4">
              <Database className="w-6 h-6 text-emerald-600" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-3">
              Continuous Learning
            </h3>
            <p className="text-gray-600 leading-relaxed">
              Every image you upload helps improve our model. The system learns
              from your data to provide better predictions over time
            </p>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-8 transform transition hover:scale-105">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
              <CheckCircle className="w-6 h-6 text-green-600" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-3">
              Treatment Guidance
            </h3>
            <p className="text-gray-600 leading-relaxed">
              Get detailed information about detected diseases including symptoms,
              causes, and recommended treatment methods
            </p>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-10 mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">
            How It Works
          </h2>
          <div className="space-y-6">
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-8 h-8 bg-green-600 text-white rounded-full flex items-center justify-center font-bold">
                1
              </div>
              <div>
                <h4 className="font-semibold text-gray-900 mb-1">Upload Leaf Image</h4>
                <p className="text-gray-600">
                  Take a clear photo of the affected leaf and upload it to our system
                </p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-8 h-8 bg-green-600 text-white rounded-full flex items-center justify-center font-bold">
                2
              </div>
              <div>
                <h4 className="font-semibold text-gray-900 mb-1">AI Analysis</h4>
                <p className="text-gray-600">
                  Our CNN model processes the image and identifies potential diseases
                </p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-8 h-8 bg-green-600 text-white rounded-full flex items-center justify-center font-bold">
                3
              </div>
              <div>
                <h4 className="font-semibold text-gray-900 mb-1">Get Results</h4>
                <p className="text-gray-600">
                  Receive detailed diagnosis with treatment recommendations and confidence scores
                </p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-8 h-8 bg-green-600 text-white rounded-full flex items-center justify-center font-bold">
                4
              </div>
              <div>
                <h4 className="font-semibold text-gray-900 mb-1">Provide Feedback</h4>
                <p className="text-gray-600">
                  Your feedback helps train the model to become more accurate for everyone
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="text-center flex flex-col sm:flex-row gap-4 justify-center">
          <button
            onClick={onStart}
            className="inline-flex items-center gap-3 bg-green-600 hover:bg-green-700 text-white font-semibold px-10 py-4 rounded-xl shadow-lg transform transition hover:scale-105 text-lg"
          >
            <Leaf className="w-6 h-6" />
            Start Detection
          </button>
          {isAuthenticated && (
            <button
              onClick={onStart}
              className="inline-flex items-center gap-3 bg-blue-600 hover:bg-blue-700 text-white font-semibold px-10 py-4 rounded-xl shadow-lg transform transition hover:scale-105 text-lg"
            >
              <History className="w-6 h-6" />
              View History
            </button>
          )}
        </div>

        <div className="mt-12 text-center text-sm text-gray-500">
          <p>
            Helping farmers worldwide protect their crops through AI-powered early disease detection
          </p>
        </div>
      </div>
    </div>
  );
}
