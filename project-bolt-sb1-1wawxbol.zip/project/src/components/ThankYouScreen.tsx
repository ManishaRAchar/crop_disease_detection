import { CheckCircle, Leaf, RotateCcw, TrendingUp } from 'lucide-react';

interface ThankYouScreenProps {
  onRestart: () => void;
}

export default function ThankYouScreen({ onRestart }: ThankYouScreenProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 flex items-center justify-center px-4">
      <div className="max-w-2xl w-full">
        <div className="bg-white rounded-2xl shadow-2xl p-12 text-center">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-green-600 rounded-full mb-6 animate-bounce">
            <CheckCircle className="w-12 h-12 text-white" />
          </div>

          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Thank You!
          </h1>

          <p className="text-xl text-gray-600 mb-8 leading-relaxed">
            Your contribution has been recorded and will help improve our
            disease detection model for farmers worldwide.
          </p>

          <div className="grid md:grid-cols-3 gap-6 mb-10">
            <div className="p-6 bg-green-50 rounded-xl">
              <Leaf className="w-8 h-8 text-green-600 mx-auto mb-3" />
              <h3 className="font-semibold text-gray-900 mb-2">
                Data Saved
              </h3>
              <p className="text-sm text-gray-600">
                Your image and feedback are securely stored
              </p>
            </div>

            <div className="p-6 bg-blue-50 rounded-xl">
              <TrendingUp className="w-8 h-8 text-blue-600 mx-auto mb-3" />
              <h3 className="font-semibold text-gray-900 mb-2">
                Model Learning
              </h3>
              <p className="text-sm text-gray-600">
                Your data will train the next model version
              </p>
            </div>

            <div className="p-6 bg-emerald-50 rounded-xl">
              <CheckCircle className="w-8 h-8 text-emerald-600 mx-auto mb-3" />
              <h3 className="font-semibold text-gray-900 mb-2">
                Community Impact
              </h3>
              <p className="text-sm text-gray-600">
                Helping farmers detect diseases earlier
              </p>
            </div>
          </div>

          <div className="bg-gradient-to-r from-green-600 to-emerald-600 rounded-xl p-8 mb-8 text-white">
            <h2 className="text-2xl font-bold mb-3">
              Continuous Learning System
            </h2>
            <p className="text-green-50 leading-relaxed">
              Every image you submit contributes to a growing dataset that makes
              our AI more accurate. Your feedback helps the model learn from real-world
              cases, making crop disease detection more reliable for everyone.
            </p>
          </div>

          <button
            onClick={onRestart}
            className="w-full py-4 bg-gray-900 hover:bg-gray-800 text-white font-semibold rounded-xl shadow-lg transition flex items-center justify-center gap-3 text-lg"
          >
            <RotateCcw className="w-6 h-6" />
            Analyze Another Image
          </button>

          <p className="mt-6 text-sm text-gray-500">
            Together, we're building a smarter agricultural future
          </p>
        </div>
      </div>
    </div>
  );
}
