import { supabase } from './supabase';
import { AuthError } from '@supabase/supabase-js';

export interface AuthUser {
  id: string;
  email: string;
}

export async function signUp(email: string, password: string): Promise<{ user: AuthUser; error: null } | { user: null; error: AuthError }> {
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
  });

  if (error) {
    return { user: null, error };
  }

  if (!data.user) {
    return { user: null, error: new AuthError('User creation failed', 500) };
  }

  return {
    user: {
      id: data.user.id,
      email: data.user.email || '',
    },
    error: null,
  };
}

export async function signIn(email: string, password: string): Promise<{ user: AuthUser; error: null } | { user: null; error: AuthError }> {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });

  if (error) {
    return { user: null, error };
  }

  if (!data.user) {
    return { user: null, error: new AuthError('Sign in failed', 500) };
  }

  return {
    user: {
      id: data.user.id,
      email: data.user.email || '',
    },
    error: null,
  };
}

export async function signOut(): Promise<{ error: AuthError | null }> {
  const { error } = await supabase.auth.signOut();
  return { error };
}

export async function getCurrentUser(): Promise<AuthUser | null> {
  const { data } = await supabase.auth.getSession();

  if (!data.session?.user) {
    return null;
  }

  return {
    id: data.session.user.id,
    email: data.session.user.email || '',
  };
}
