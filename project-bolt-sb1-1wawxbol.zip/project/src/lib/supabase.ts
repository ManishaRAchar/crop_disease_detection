import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface DiseaseCategory {
  id: string;
  name: string;
  description: string;
  symptoms: string;
  treatment: string;
  created_at: string;
}

export interface DiseaseDetection {
  id: string;
  image_url: string;
  detected_disease_id: string;
  confidence_score: number;
  user_feedback: string;
  is_verified: boolean;
  created_at: string;
}

export interface TrainingData {
  id: string;
  detection_id: string;
  image_url: string;
  actual_disease_id: string;
  used_for_training: boolean;
  created_at: string;
}
